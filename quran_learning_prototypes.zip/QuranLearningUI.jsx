import React from "react";
export default function QuranLearningApp() {
  return <div className="p-4">Quran UI Demo</div>;
}